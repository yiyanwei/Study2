Before clicking `Submit new issue`, try the latest build [![](https://github.com/0xd4d/dnSpy/workflows/GitHub%20CI/badge.svg)](https://github.com/0xd4d/dnSpy/actions)

- What version did you use?

- Write down all steps needed to reproduce this issue. Also attach any needed files.
